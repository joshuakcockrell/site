# Group 8 Ticket To Ride

Full Java package name of your server's "main" class
com.thamj.cs340.tickettoride.server.ServerCommunicator


Explanation of any command-line parameters accepted by your server
port - just give it a number, no quotes
for example: server 3000

Java package name of your client app 
com.thamj.cs340.tickettoride.client

The type/size of emulator/device your app should be tested on
Nexus 10 API 25 (Android 7.1, API 25)
Release Name: Nougat
API Level: 25
ABI: x86
Target: Android 7.1.1
Orientation: Landscape

to start server:
run ./start_server or
double click on start_server or
run 
$ java -jar server-all-1.0.jar <port num>

to start emulator:
edit the ./start_emulator file with your own username or path to sdk emulator
run ./start_emulator

to start app:
edit the ./start_app file with your own username or path to adb
run ./start_app


